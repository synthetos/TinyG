#ifndef _FLASH_DEFINES_
#define _FLASH_DEFINES_


	#define FLASH_PAGE_SIZE 512




#endif
