/*
	protocol.h
	TinyG protocol state machine definitions and otehr common data
	Written by: Alden Hart
	Revision: 03/21/10
*/
