/*
  encoder.h - encoder interfaces
  Part of TinyG

  Copyright (c) 2010 Alden S Hart, Jr.

*/

#ifndef encoder_h
#define encoder_h

/* function prototypes */

void en_init(void);


#endif
